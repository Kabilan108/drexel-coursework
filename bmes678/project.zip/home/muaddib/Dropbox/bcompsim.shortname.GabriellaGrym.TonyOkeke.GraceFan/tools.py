import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

from typing import Callable


def style_axis(
    ax: plt.axes,
    xlab: str = "",
    ylab: str = "",
    xgrid: bool = True,
    ygrid: bool = True,
    lab_size: int = 11,
) -> None:
    ax.minorticks_on()
    ax.spines[["top", "right"]].set_visible(False)

    if xlab:
        ax.set_xlabel(xlab, fontsize=lab_size)
    if ylab:
        ax.set_ylabel(ylab, fontsize=lab_size)

    if xgrid:
        ax.xaxis.grid(True, which="major", color="gray", alpha=0.6, linewidth=0.5)
        ax.xaxis.grid(
            True, which="minor", color="gray", alpha=0.6, linewidth=0.2, linestyle="--"
        )
    if ygrid:
        ax.yaxis.grid(True, which="major", color="gray", alpha=0.6, linewidth=0.5)
        ax.yaxis.grid(
            True, which="minor", color="gray", alpha=0.6, linewidth=0.2, linestyle="--"
        )


def rk4(
    fprime: Callable,
    timespan: tuple[float, float],
    y0: list[float],
    h: float = 0.1,
) -> tuple:
    """Fourth-Order Runge-Kutta method for solving ODEs"""

    x0, xend = timespan
    X = np.array([x0 + i * h for i in range(int(np.ceil((xend - x0) / h)))])
    Y = np.empty((len(X), len(y0)))
    Y[0, :] = y0

    for i in range(1, X.shape[0]):
        K1 = h * fprime(X[i - 1], Y[i - 1, :])
        K2 = h * fprime(X[i - 1] + h / 2, Y[i - 1, :] + K1 / 2)
        K3 = h * fprime(X[i - 1] + h / 2, Y[i - 1, :] + K2 / 2)
        K4 = h * fprime(X[i - 1] + h, Y[i - 1, :] + K3)
        Y[i, :] = Y[i - 1, :] + (K1 + 2 * K2 + 2 * K3 + K4) / 6

    return X, Y


def extract_metrics(t, Y):
    """Extract metrics from simulation data"""

    populations = ["Susceptible", "Exposed", "Infected", "Recovered"]
    peaks = np.max(Y, axis=0)
    time_to_peaks = [t[np.argmax(Y[:, i])] for i in range(4)]

    data = {"population": populations, "peak": peaks, "time-to-peak": time_to_peaks}

    df = pd.DataFrame(data).set_index("population")
    return df


def run_sensitivity_analysis(
    model: Callable,
    params: list[float],
    param_names: list[str],
    perturbation: float = 0.5,
):
    """Run sensitivity analysis for a given model

    Will run the model with the given parameters, and then for each parameter,
    will perturb the parameter by the given perturbation amount, and then run
    the model again. The 'peak' and 'time-to-peak' metrics will be returned for
    each parameter. And the average % change for each parameter will be returned.
    """

    sensitivity = []
    sim_params = params.copy()

    T, Y = model(sim_params)
    default_metrics = extract_metrics(T, Y)

    for i in range(len(params)):
        for pert in [perturbation, -perturbation]:
            print(f"--- running with {param_names[i]} perturbed by {pert*100}%")
            sim_params[i] = params[i] * (1 + pert)
            T, Y = model(sim_params)
            metrics = extract_metrics(T, Y)
            change = (metrics - default_metrics).abs() / default_metrics.replace(0, 1)
            change["param"] = param_names[i]
            sensitivity.append(change)

    results = (
        pd.concat(sensitivity)
        .reset_index()
        .groupby(["param", "population"])
        .mean()
        .reset_index()
    )

    return results


def plot_sensitivity_results(results, param_names):
    fig, axes = plt.subplots(2, 1, figsize=(6, 6))
    for i, (metric, ax) in enumerate(zip(["peak", "time-to-peak"], axes)):
        pivot_table = results.pivot(
            index="population", columns="param", values=metric
        ).reindex(["Susceptible", "Exposed", "Infected", "Recovered"])

        sns.heatmap(
            pivot_table,
            annot=True,
            cmap="flare_r",
            fmt=".2%",
            vmin=0,
            vmax=1,
            annot_kws={"size": 10},
            cbar_kws={"format": "{x:.0%}"},
            ax=ax,
        )
        ax.set_xlabel(None)
        ax.set_ylabel(None)
        ax.set_xticklabels(param_names, fontsize=12)
        ax.set_yticklabels(["S", "E", "I", "R"], fontsize=12, rotation=0)
        ax.set_title(f"{metric} values", fontsize=12)

    fig.tight_layout()
    fig.subplots_adjust(top=0.9)
    fig.suptitle("% Change in Population Metrics with 50% Perturbations", fontsize=14)
